
public class Ch2PA2 {

	public static void main(String[] args) {
		// 1 inch = 25.4 mm
		double mm = 25.4;
		
		// Output
		System.out.println("2 inches = " +2*mm+ " mms\n"
				+ "5 inches = " +5*mm+ "mms\n"
				+ "10 inches = " +10*mm+ "mms");

	}

}
