
public class Ch2Lab1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println();
		System.out.println("Welcome!");
		System.out.println("To Java I: CIT 149");
		System.out.println();

	}

}
